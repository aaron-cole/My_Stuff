require 'facter'

Facter.add('taniumclient_installedversion') do
    setcode '/bin/rpm -q --queryformat "%{VERSION}" TaniumClient'
end

Facter.add('taniumclient_serverport') do
    setcode '/opt/Tanium/TaniumClient/TaniumClient config get ServerPort'
end

Facter.add('taniumclient_version') do
    setcode '/opt/Tanium/TaniumClient/TaniumClient config get Version'
end

Facter.add('taniumclient_loglevel') do
    setcode '/opt/Tanium/TaniumClient/TaniumClient config get LogVerbosityLevel'
end

Facter.add('taniumclient_servername') do
    setcode '/opt/Tanium/TaniumClient/TaniumClient config get ServerName'
end