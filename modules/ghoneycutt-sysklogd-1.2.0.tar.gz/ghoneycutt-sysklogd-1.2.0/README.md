# puppet-module-sysklogd
===


[![Build Status](
https://api.travis-ci.org/ghoneycutt/puppet-module-sysklogd.png)](https://travis-ci.org/ghoneycutt/puppet-module-sysklogd)

Puppet module to remove sysklogd.

This is needed on EL 5 systems to replace sysklogd with another syslogger such as syslog_ng or rsyslog.

===

# Compatibility

This module has been tested to work on the following systems with the
latest Puppet v3, v3 with future parser, v4, v5 and v6.  See `.travis.yml`
for the exact matrix of supported Puppet and ruby versions.

* EL 5
