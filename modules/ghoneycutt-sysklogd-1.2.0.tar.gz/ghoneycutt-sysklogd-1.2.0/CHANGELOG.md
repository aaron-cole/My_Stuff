### v1.2.0 - 2019-01-03
  Support Puppet 5 and 6

### v1.0.1 - 2013-07-23

  Garrett Honeycutt
    cd30238 Add metadata for the Forge
    09e2b5b Support Ruby v2.0.0
    f97217e Support Puppet v3.5 and v3.6
    43d6738 Allow for forge metadata
    f0ea038 minor style updates
    5e76fb6 Use single quotes where variable interpolation is not needed
    53b4f92 Support Facter v2
    e170f17 Remove unused bundler configuration
    45fee8f Update license for 2014
    1235dce Do not require rubygems as it is not needed

### v1.0.0 - 2013-05-24

  Martin Hagstrom
    f31b1af Martin Hagstrom Cleanup of documentation

  Garrett Honeycutt
    ccf0e0f Add README with Travis link and enable testing ruby 1.9.3
    7e52996 Travis-CI support
    c425524 Add spec test

### v0.0.1 - 2013-05-17 Garrett Honeycutt <code@garretthoneycutt.com>
  Initial release
